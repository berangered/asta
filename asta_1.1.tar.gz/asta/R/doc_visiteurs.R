#' visiteurs
#'
#' Le fichier visiteur est nombre de visiteurs d'un musée
#'
#' @name visiteurs
#' @docType data
#' @author Jean \email{jean.sebban@@insee.fr}
#' @source {Openclassroom}
#' @format visiteurs est une série temporelle.
#' @keywords data
"visiteurs"
help(visiteurs)