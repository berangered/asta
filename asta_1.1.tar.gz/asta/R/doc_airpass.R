#' airpass
#'
#' Le fichier airpass est directement issu du package dataset (AirPassengers)
#'
#' @name airpass
#' @docType data
#' @author Jean \email{jean.sebban@@insee.fr}
#' @source \url{https://cefil.org/} {Site du Cefil}
#' @format airpass est une série temporelle.
#' @keywords data
"airpass"
help(airpass)